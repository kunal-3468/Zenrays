import React from 'react'
import { useTable } from 'react-table'
import "../App.css"
 
function Home() {
  const data = React.useMemo(
    () => [
      {
        col1: 'AIML',
        col2: '3.5 Months',
      },
      {
        col1: 'Machine Learning',
        col2: '1.5 Months',
      },
      {
        col1: 'Angular',
        col2: '1.5 Months',
      },
      {
        col1: 'Mean Stack',
        col2: '1.5 Months',
      },
      {
        col1: 'React',
        col2: '1.5 Months',
      },
      {
        col1: 'Python',
        col2: '1.5 Months',
      },
      {
        col1: 'Django',
        col2: '2.5 Months',
      },
      {
        col1: 'Full-Stack',
        col2: '3.5 Months',
      },
      {
        col1: 'UI- Development',
        col2: '2 Months',
      },
      {
        col1: 'Web Development',
        col2: '2.5 Months',
      },
    ],
    []
  )

  const columns = React.useMemo(
    () => [
      {
        Header: 'Course Name',
        accessor: 'col1',
      },
      {
        Header: 'Duration',
        accessor: 'col2',
      },
    ],
    []
  )

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({ columns, data })

  return (
    <table {...getTableProps()} className="reactTab">
      <thead>
        {headerGroups.map(headerGroup => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map(column => (
              <th
                {...column.getHeaderProps()}
                style={{
                  borderBottom: 'solid 3px red',
                  background: 'aliceblue',
                  color: 'black',
                  fontWeight: 'bold',
                }}
              >
                {column.render('Header')}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map(row => {
          prepareRow(row)
          return (
            <tr {...row.getRowProps()}>
              {row.cells.map(cell => {
                return (
                  <td
                    {...cell.getCellProps()}
                    style={{
                      padding: '10px',
                      border: 'solid 1px gray',
                      background: 'papayawhip',
                    }}
                  >
                    {cell.render('Cell')}
                  </td>
                )
              })}
            </tr>
          )
        })}
      </tbody>
    </table>
  )
}

export default Home;