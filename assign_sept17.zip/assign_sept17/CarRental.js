import About from "./About";
import ContactUs from "./ContactUs";
import Employees from "./Employees";
import "../App.css";
import { BrowserRouter as Router , Switch, Route, Link } from "react-router-dom";
import Home from "./Home";

function CarRental(){

    return(
        <div>
          <Router>
            <div className="links">
            <Link to="/" className="link">Home</Link>
            <Link to="/about" className="link">About Us</Link>
            <Link to="/contact" className="link" >Contact Us</Link>
            <Link to="/employees" className="link" >Emplyees Info</Link>
            </div>
          <Switch>
            <Route exact path="/">
               <Home />
            </Route>
            <Route path="/about">
              <About />
            </Route>
            <Route path="/contact">
              <ContactUs />
            </Route>
            <Route path="/employees">
              <Employees />
            </Route>
          </Switch>
          </Router>
        </div>
      )
}

export default CarRental;