import { useState } from "react";

function Calculator() {

    const [value, calculation] = useState();

    function submit(event) {

        event.preventDefault();

        let formOb = event.target;
        let fv = parseInt(formOb.a.value);
        let sv = parseInt(formOb.b.value);
        let operation = formOb.calculator.value;

        console.log(fv);
        console.log(sv);
        console.log(operation);

        if (operation == "add") {
            calculation(fv + sv);
        }
        else if (operation == "subtract") {
            calculation(Math.abs(fv + sv));
        }
        else if (operation == "multiply") {
            calculation(fv * sv);
        }
        else if (operation == "divide") {
            calculation(fv / sv);
        }

    }

    return (
        <div>
            <form onSubmit={submit}>
                Enter First Value : <input type="number" name="a" /><br /><br />
                Enter Second Value :  <input type="number" name="b" /><br /><br />
                <label for="calculator">Choose Operation:</label>

                <select name="calculator" id="calculator">
                    <option>Select</option>
                    <option value="add">Add</option>
                    <option value="subtract">Subtract</option>
                    <option value="multiply">Multiply</option>
                    <option value="divide">Divide</option>
                </select><br /><br />
                <button>Submit</button>
            </form>
            <hr />
            <br />
            <h2>Answer is {value}</h2>
        </div>
    )
}

export default Calculator;