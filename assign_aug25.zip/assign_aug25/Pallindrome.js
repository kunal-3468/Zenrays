function Pallindrome(){

    function check(event){

        event.preventDefault();

        let word = event.target.word.value;

        let splitWord = word.split("");

        let reverse = splitWord.reverse();

        let reverseWord = reverse.join('');

        if(word == reverseWord){
            document.getElementById("output").innerHTML = `"${word}" is Pallindrome`;
        }else{
            document.getElementById("output").innerHTML = `"${word}" is Not Pallindrome`;
        }
    }

    return(
         <div>
             <form onSubmit={check}>
             Enter Any Word : <input type="text" name="word"/>
             <button>Check</button>
             </form>
             <h2 id="output"></h2>
         </div>
    )
}

export default Pallindrome;