function PrimeSum(){

    function doSum(event){
         
        event.preventDefault();

        let no = parseInt(event.target.no.value);

        let a=3;
        let prime = true;
        let arr =[2];

        while(arr.length < no){
              
             for(let i=2;i<a;i++){
                 if(a%i == 0){
                      prime = false;
                      break;
                 }   else{
                     prime = true;
                 }
             }
             if(prime == true){
                 arr.push(a);
             }
             a++;
        }

        console.log(arr);
        
        let sum = arr.reduce((a,b)=>{
            return a+b;
        })

        alert(`Sum of first ${no} is ${sum}`);
    }

    return(
         <div>
             <form onSubmit={doSum}>
             Enter a number : <input type="number" name="no" />
             <button>Submit</button>
             </form>
         </div>
    )
}

export default PrimeSum;