function Reverse(){

    function doReverse(event){

        event.preventDefault();

        let word = event.target.word.value;

        let splitWord = word.split("");

        let reverse = splitWord.reverse();

        let reverseWord = reverse.join('');
        
        document.getElementById("output").innerHTML = `Reverse of "${word}" is ${reverseWord}`; 
    }

    return(
         <div>
             <form onSubmit={doReverse}>
             Enter Any Word : <input type="text" name="word"/>
             <button>Submit</button>
             </form>
             <h2 id="output"></h2>
         </div>
    )
}

export default Reverse;