import {useState} from "react";

function Registration(){

   const [vals,details] = useState([]);

   function add(event){
         
    event.preventDefault();

    let formOb = event.target;

    let name = formOb.name.value;
    let age = formOb.age.value;
    let loc = formOb.loc.value;
    let interest = formOb.interest.value;
    let wp = formOb.wp.value;
    let des = formOb.des.value;

    details([name,age,loc,interest,wp,des]);
    
   }
     
    return(
        <div>
            <form onSubmit={add}>
                Enter Name : <input type="text" name="name"/><br/><br/>
                Enter Age : <input type="text" name="age"/><br/><br/>
                Enter Location : <input type="text" name="loc"/><br/><br/>
                Enter Interest : <input type="text" name="interest"/><br/><br/>
                Enter Webpage : <input type="url" name="wp"/><br/><br/>
                Enter Description : <textarea name="des" rows="3" cols="20"></textarea><br/><br/>
                <button>Submit</button>
            </form><br/><br/>
            <h1></h1>
            <table border="2">
                <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Location</th>
                    <th>Interest</th>
                    <th>Web Page</th>
                    <th>Description</th>
                </tr>
                <tr>
                    {
                        vals.map((val)=>{
                             return <td>{val}</td>
                        })
                    }
                </tr>
            </table>
        </div>
    )
}

export default Registration