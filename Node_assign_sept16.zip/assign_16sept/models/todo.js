const mongoose = require("mongoose");

const todoSchema = new mongoose.Schema({

	 name: String,
	 status: Boolean,
	 creation_date : Date,
})

module.exports = mongoose.model("Todo", todoSchema);