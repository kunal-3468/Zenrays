var express = require('express');
var router = express.Router();

const authorController = require("../controllers/author")
const todoController = require("../controllers/todo")

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express', mood : "Active" });
});

router.get("/contact", function(req,res,next) {

   res.send("<h1>Thanks for Contacting Us :)</h1>")
})

router.post("/author",authorController.createAuthor);
router.get("/author", authorController.getAuthors);
router.get("/author/:id", authorController.getAuthor);

router.post("/todo", todoController.createTodo);
router.get("/todo", todoController.getTodos);
router.get("/todo/:id", todoController.getTodo)

module.exports = router;
