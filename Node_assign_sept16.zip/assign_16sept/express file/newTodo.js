var express = require("express");
var app = express();

app.get("/",function(req,res){
      
     res.send(`
         <form method="post" action="http://localhost:3000/todo">
             <h2>
                Enter Activity Todo : <input type="text" name="name" />
                Enter Status : 
                <select name="status">
                   <option>Select Status</option>
                   <option value="true">True</option>
                   <option value="false">False</option>
                </select>
             </h2>
             <button>Submit</botton>
         </form>
     `)
})

app.listen(4000)