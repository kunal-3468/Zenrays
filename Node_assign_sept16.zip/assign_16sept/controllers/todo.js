const Todo = require("../models/todo");

exports.createTodo = function(req,res){

	 //const {name,status,creation_date} = req.body;

	 const todoOb = new Todo({
	 	  name : req.body.name,
	 	  status : req.body.status,
	 	  creation_date : new Date(),
	 })

	 todoOb.save(function(err){

	 	 if(err){
	 	 	console.log(err);
	 	 }else{
	 	 	console.log("Successsfully inserted.");
	 	 	res.json({msg:"Todo Added."})
	 	 }
	 })
}

exports.getTodos = function(req,res){

	     Todo.find(function(err,list){

	 	   res.json(list)
	 });
}

exports.getTodo = function(req,res){

	     Todo.findById(req.params.id,function(err,todo){

	   	     res.json(todo);
	   })
}