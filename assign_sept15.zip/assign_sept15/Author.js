import { useState, useEffect } from "react";
import axios from "axios";

function Author(){

    const [output,setOutput] = useState([]);
    const [loading,setLoading] = useState(false);

    function add(event){

        event.preventDefault();

        let details = {
             first_name : event.target.fn.value,
             last_name : event.target.ln.value,
             dob : event.target.dob.value,
             dod : event.target.dod.value
        }

        setLoading(true);

        console.log(details);

        axios.post("/author",details).then(res =>{
             console.log(res);
        })
        .finally(function(){
            setLoading(false);
            
            alert("Author Successfully Added.")
        })

        event.target.fn.value="";
        event.target.ln.value="";
        event.target.dob.value="";
        event.target.dod.value="";

    }

    // function doDelete(id){
          
    //     axios.delete("/author/"+id).then(res =>{
    //         console.log(res);
    //     })
    // }

    useEffect(function(){

        axios.get("/author").then((res)=>{

            setOutput(res.data);
        })
        
    },[output])

    return(
        <div>
            <form onSubmit={add}>
                <h2>
                    Enter Firstname : {" "} <input type="text" name="fn" /><br />
                    Enter Lastname : {" "} <input type="text" name="ln" /><br />
                    Enter Date of Birth : {" "} <input type="date" name="dob" /><br />
                    Enter Date of Death : {" "} <input type="date" name="dod" /><br />
                </h2>
                <button>Submit</button>
            </form>
            <br/><br/>
           {loading ? <img src="Spinning_arrows.gif" /> : "" }
           <br/><hr/>
           <table border="2">
               <tr>
                   <th>First Name</th>
                   <th>Last Name</th>
                   <th>Date of Birth</th>
                   <th>Date of Death</th>
               </tr>
               {
                   output.map(val =>{     
                       return(
                           <tr>
                               <td>{val.first_name}</td>
                               <td>{val.last_name}</td>
                               <td>{val.dob.slice(0,10)}</td>
                               <td>{val.dod.slice(0,10)}</td>
                           </tr>
                       )
                   })
               }
           </table>
        </div>
    )
}

export default Author;