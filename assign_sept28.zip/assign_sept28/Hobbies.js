import { Button, TextField } from "@mui/material";
import { IconButton, List, ListItem, ListItemText, Tooltip } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete'
import useLocalStorage from "./useLocalStorage";

function Hobby() {

    let [Hobbies,setHobby] = useLocalStorage("Hobbies",["Reading","Playing Snooker"]);

    const addHobby =(event) =>{
         event.preventDefault();

         let newHobby = [...Hobbies, event.target.name.value];

         setHobby(newHobby);

         event.target.name.value="";
    }

    const clearAll = () =>{
         
        setHobby([]);
    }

    const deleteHobby = (indexToDelete) =>{
         
        let filterHobbies= Hobbies.filter((val,index) =>{
               
            if(indexToDelete == index) {
                
                return false
            };

            return true;
        })        
       
        setHobby(filterHobbies);
    }


    return (
        <div style={{padding: "10px"}}>
            <Button type="button" onClick={clearAll} variant="contained">Clear All</Button>
            <br/><br/>
            <form onSubmit={addHobby}>
            <TextField name="name" label="Enter Your Hobby" variant="outlined" />{"   "}
            <Button type="submit" variant="contained">Add</Button>
            </form>
            <br/><hr/>
            <List style={{ width: '20%', maxWidth: 360, backgroundColor: '#f5f5f5', padding: '10px' }}>
                {Hobbies.map((val, index) => {
                    return (
                        <ListItem
                            key={val}
                            disableGutters
                            secondaryAction={
                                <Tooltip title="Delete">
                                    <IconButton>
                                        <DeleteIcon type="button" onClick={() => {deleteHobby(index) }} />
                                    </IconButton>
                                </Tooltip>
                            }
                        >
                            <ListItemText primary={val} />
                        </ListItem>
                     )
                    })}
            </List>    
        </div>
    )

}

export default Hobby;
