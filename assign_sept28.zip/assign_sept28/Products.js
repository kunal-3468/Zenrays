import { Button, TextField } from "@mui/material";
import ReactStars from "react-rating-stars-component";
import { useState } from "react";
import "../App.css"

function Products() {

    const [Products, setProduct] = useState([]);

    const addProduct = (event) => {

        event.preventDefault();

        let prod = {
            name: event.target.name.value,
            price: event.target.price.value,
            desc: event.target.desc.value
        }

        let newProd = [...Products,prod]

        setProduct(newProd);

        alert("Product Added");

        event.target.name.value = "";
        event.target.price.value = "";
        event.target.desc.value = "";
    }

    return (
        <div>
            <h1>Add Product : </h1><br />
            <form onSubmit={addProduct}>
                <TextField name="name" label="Enter Product Name" variant="outlined" />{"  "}
                <TextField name="price" label="Enter Product Price" variant="outlined" />{"  "}
                <TextField name="desc" label="Enter Product Description" variant="outlined" />{"   "}
                <Button type="submit" variant="contained">Add</Button>
            </form>
            <br /><hr /><br />
            <h1>Products : </h1>
            <ul>
               {
                   Products.map(val =>{
                       return(
                           <li><h3>Name: {val.name}<br/>
                               Price: {val.price}<br/>
                               Description: {val.desc}<br/>
                               Give Ratings : <ReactStars count={5} size={24} activeColor="#ffd700"/>  
                               </h3><br/><hr/>
                            </li>
                       )
                   })
               }
            </ul>
        </div>
    )

}

export default Products;