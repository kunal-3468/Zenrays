import { useState, useRef, useEffect } from "react";
import axios from "axios";

function Todo(){

    const [todos, setTodos] = useState([]);
    const [editIndex, setEditIndex] = useState();
    const [count,setCount] = useState(0);
    const [a,seta] = useState();
    const inputRef = useRef(null);


    useEffect(function(){
        getTodo();
    },[])

    function getTodo(){
          
        axios.get("/newtodo").then((res)=> {
              
            console.log(res.data);

            setTodos(res.data);

            setEditIndex(-1);
        })
    }

    function addTodo(event){

        event.preventDefault();
         
        let data = {     
           name: event.target.name.value 
        } ;

        console.log(data);

        axios.post("/newtodo", data).then((res)=>{
             
            console.log(res.data)
        }).catch((err)=>{
            console.log(err);
        })

        getTodo();

        event.target.name.value= "";

        setCount(count+1);
    }

    function editTodo(index){

        console.log(index);

        setEditIndex(index);  
        
        inputRef.current.value = todos[index].name;

        }

    function updateTodo(){

        let id = todos[editIndex]._id;

        console.log(id);

        console.log(inputRef.current.value);

        let data2 = {
            name : inputRef.current.value
        }

        axios.put("/newtodo/"+ id, data2).then((res)=>{
             
            console.log(res.data);
        }).catch((err)=>{
            console.log(err);
        })

        getTodo();

        inputRef.current.value= "";

        setCount(count+1);
    }

    function deleteTodo(index){

        let id = todos[index]._id;

        axios.delete("/newtodo/"+ id).then((res)=>{
            console.log(res.data)
        }).catch((err)=>{
            console.log(err);
        })

        getTodo();
    }

    function showCount(){

        seta(count);
    }

    return(
        <div style={{padding: "20px"}}>
        <br/><br/>
            <form onSubmit={addTodo}>
                <input type="text" name="name" ref={inputRef} /> {" "}
                {editIndex > -1 ? (<button type="button" onClick={updateTodo}>Update</button>) : (<button>Add</button>)}
            </form>
            <ul>
                <h3>Activities Todo :-</h3>
                {todos.map((val,index)=>{
                  return(
                      <li>{val.name} {" "} 
                      <button onClick={() => editTodo(index)}>Edit</button> {" "}
                      <button onClick={() => deleteTodo(index)}>Delete</button>
                      </li>
                  )
            })}
            </ul>
            <br/><hr/><br/>
            <button onClick={showCount}>Count</button>
            <br/>
            <h2>The number of times the Add and Update API called :- {a} </h2>
        </div>
    )
}

export default Todo;