import { BrowserRouter, Switch, Route } from "react-router-dom";
import Home from "./home";
import Login from "./login";

function Routing(){
      
    return(
        <BrowserRouter>
             <Switch>
                <Route exact path="/" component={Login} />
                <Route path="/home" component={Home} />
             </Switch>
        </BrowserRouter>
    )
}

export default Routing;