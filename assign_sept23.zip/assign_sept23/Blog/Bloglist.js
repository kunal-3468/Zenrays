import { BrowserRouter, Link ,Route, Switch } from "react-router-dom";
import Blogdetails from "./Blogdetails";

function Bloglist(){

    return(
        <div>     
            <h1>Blogs : </h1>
             <BrowserRouter>
               <h2>
                 <Link to="/Blogdetails/1">10 Disabled YouTubers You Should Subscribe To For Learning More About Life With Disabilities</Link><br/><br/>
                 <Link to="/Blogdetails/2">A Timeline Of The Science Behind Cure Rare Disease</Link><br/><br/>
                 <Link to="/Blogdetails/3">Small Business Administration</Link><br/><br/>
                 <Link to="/Blogdetails/4">Derek Sivers’ Blog</Link><br/><br/>
               </h2>
               <hr/>
                 <Switch>
                    <Route path="/Blogdetails/:id" component={Blogdetails}></Route>
                 </Switch>
           </BrowserRouter>
        </div>
    )
}

export default Bloglist;