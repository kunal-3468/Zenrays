import { Button, TextField } from "@mui/material";

function BlogComment({addComment,comment}){

    return(
        <div>
            <form onSubmit={addComment}>
            <TextField name="cmnt" label="Add Comment" variant="outlined" /><br/><br/>
            <Button type="submit" variant="contained">Add</Button>
            </form>
            <h2>Comments :</h2>
            {
                comment.map((val) => {
                    return(
                        <p>{val}</p>
                    )
                })
            }
            
        </div>
    )
}

export default BlogComment;