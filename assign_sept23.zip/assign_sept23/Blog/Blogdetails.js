import { useEffect } from "react";
import { useState } from "react";
import { useParams } from "react-router";
import BlogComment from "./BlogComment";
import blogData from "./data.json"
function Blogdetails(){

    console.log(blogData);

    const [data, setData] = useState({});

    let { id } = useParams();

    console.log(id);

    useEffect(function(){
         blogData.forEach(val =>{
              if(id == val.id){
                  setData(val);
              }
         })
    },[id])

    const [comment,setComment] = useState([]);

   const addComment = (event) =>{

    event.preventDefault();

    let cmnt = event.target.cmnt.value;

    let newCmnt = [...comment,cmnt];

    setComment(newCmnt);

    event.target.cmnt.value="";
   }
      
    return(
        <div style={{padding:'10px'}}>
            <h1>{data.title}</h1>
            <p>{data.content}</p>
            <h3>Creation Date: {data.creation_date}</h3>
            <h3>Author : {data.author} </h3>
            <h3>ID : {data.id}</h3>
            <BlogComment addComment={addComment} comment={comment} />
        </div>
    )

}

export default Blogdetails;