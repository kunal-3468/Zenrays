import { Button, TextField } from "@mui/material";
import { Component } from "react";

class Todoform extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div>

                <form style={{ padding: "20px", }} onSubmit={this.props.addTodo} >
                    <TextField name="todo" label="Enter Activity Todo" variant="outlined" /><br /><br />
                    <Button type="submit" variant="contained">Enter</Button>
                </form>

            </div>
        )
    }
}

export default Todoform;