import {Component} from "react";
import * as React from 'react';
import {TextField, Button } from '@mui/material';
import Todolist from "./Todolist";
import Todoform from "./Todoform";

class Todo23 extends Component{
     
    constructor(){

        super();

        this.state = {
            todos : ["Cycling"],
        }
    }

    addTodo = (event) => {
          
        event.preventDefault();

        console.log(event.target.todo.value);

        let newTodo = [...this.state.todos, event.target.todo.value];

        this.setState({todos : newTodo});

        event.target.todo.value="";
    }

    deleteTodo= (index) => {

        let newTodos = this.state.todos.filter((val,ind) => {
              
            if(ind == index) return false;
            return true;
        } )
        this.setState({todos : newTodos});
    }

    render(){
        return(
            <div>
                <Todoform addTodo={this.addTodo} />
                <br/><hr/>
                <h2>Todo List :-</h2>
                <Todolist todos={this.state.todos} deleteTodo= {this.deleteTodo} />
            </div>
        )
    }
}

export default Todo23;
