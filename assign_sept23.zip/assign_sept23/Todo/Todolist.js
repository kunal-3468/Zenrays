import { Component } from "react";
import { IconButton, List, ListItem, ListItemText, Tooltip } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete'

class Todolist extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <List style={{ width: '20%', maxWidth: 360, backgroundColor: '#f5f5f5', padding: '10px' }}>
                {this.props.todos.map((val, index) => {
                    return (
                        <ListItem
                            key={val}
                            disableGutters
                            secondaryAction={
                                <Tooltip title="Delete">
                                    <IconButton>
                                        <DeleteIcon type="button" onClick={() => { this.props.deleteTodo(index) }} />
                                    </IconButton>
                                </Tooltip>
                            }
                        >
                            <ListItemText primary={val} />
                        </ListItem>
                    )
                })}
            </List>
        )
    }

}

export default Todolist;

// <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
//     {[1, 2, 3].map((value) => (
//         <ListItem
//             key={value}
//             disableGutters
//             secondaryAction={
//                 <IconButton>
//                     <CommentIcon />
//                 </IconButton>
//             }
//         >
//             <ListItemText primary={`Line item ${value}`} />
//         </ListItem>
//     ))}
// </List>