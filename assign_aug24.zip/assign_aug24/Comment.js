function Comment(){

    function submit(){
         
        alert("Your Comment has been submitted, waiting for moderator");

        document.getElementById("name").value = "";
        document.getElementById("email").value = "";
        document.getElementById("text").value = "";
    }
     
    return(
        <div>
            Enter Name : <input type="text" id="name"/><br/><br/>
            Enter Email : <input type="email" id="email"/><br/><br/>
            Enter Comment : <textarea id="text" rows="2" cols="20"></textarea><br/><br/>
            <button onClick={submit}>Submit</button>
        </div>
    )
}

export default Comment;