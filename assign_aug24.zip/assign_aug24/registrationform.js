function RegistrationForm() {

    return (
            <form> 
            Enter Username : <input type="text" id="un" /><br/><br/>
            Enter Password : <input type="password" id="pass" /><br/><br/>
            Enter DOB : <input type="date" id="dob" /><br/><br/>
            <label for="education">Enter Education details :</label>
            <textarea id="education" name="eduction" rows="4" cols="50"></textarea><br/><br/>
            Select Gender : <input type="radio" id="gender" name="gender" value="male"/>Male <input type="radio" id="gender" name="gender" value="female"/>Female<br/><br/>
           <input type="Submit" value="Submit" />
           </form>
    )
}

export default RegistrationForm;