//A component is a function that returs some html.
import "./App.css";
function Login() {

    function doLogin(){

    }

	return(
        <div className="Login">
        Enter Username : <input type="text"/><br/>
        Enter Password: <input type="password"/><br/>
        <button onClick={doLogin}>Login</button><br/>
        <a href="">Reset Password</a><br/>
        <a href="">Forgot Password</a>
        </div>
		)
}
//it is imp to export so other files can use this file

export default Login;