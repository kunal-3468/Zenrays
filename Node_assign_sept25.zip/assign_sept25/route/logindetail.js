var express = require("express");

var router = express.Router();

var logindetailController = require("../controllers/logindetail");

router.post("/", logindetailController.createLogindetail);
router.get("/", logindetailController.getLogindetail);

module.exports = router;