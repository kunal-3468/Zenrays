var express = require("express");

var router = express.Router();

var userprofileController = require("../controllers/userprofile");

router.post("/", userprofileController.createUserprofile);
//router.get("/", userprofileController.getUserprofileWithLogindetails);
router.get("/", userprofileController.getUserprofile);

module.exports = router;