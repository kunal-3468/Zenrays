var Logindetail = require("../models/logindetail");

let i=1;

exports.createLogindetail = function(req,res){

    const logindetailOb = new Logindetail({
        id: i,
        username: req.body.username,
        password: req.body.password
    });

    logindetailOb.save(function(err){
          
        if(err){
            res.json({status: 0, data: err})
        }
        res.json({status: 1, data: "Login Details Saved"})
    })

    i++;
}

exports.getLogindetail = function(req,res){ 
      
    Logindetail.find(function(err,list){ 
         if(err){
             res.json({status: 0, data: err});
         }

         res.json({status: 1, data: list});
    })
}