var Userprofile = require("../models/userprofile");

exports.createUserprofile = function(req,res){
       
    const {logindetail,username,password, email, phone, city, age} = req.body;

    const userprofileOb = new Userprofile({logindetail,username,password,email,phone,city,age});

    userprofileOb.save(function(err){
          
        if(err){
            res.json({status: 0, data: err});
        }

        res.json({status:1, data: "User Saved"})
    })
}

exports.getUserprofileWithLogindetails = function(req,res){
       
    Userprofile.find().populate("logindetail").exec(function(err,list){
           
        if(err){
            res.json({status: 0, data: err});
        }

        res.json({status: 1, data: list});
    })
}

exports.getUserprofile = function(req,res){
      
    Userprofile.find(function(err,list){
          
        if(err){
            res.json({status: 0, data: err});
        }

        res.json({status: 1, data: list});
    })
}