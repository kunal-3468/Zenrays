import { useState } from "react";

function NewTodod(){
    
    const [todos,setTodo] = useState([{name:"wash",status:"complete"}]);

    console.log(todos);

    function add(event){
         
        event.preventDefault();

        let details ={
        name : event.target.name.value,
        status : event.target.status.value
        }

        console.log(details);
        
        let newtodo = [...todos, details];

        setTodo(newtodo)

        console.log(setTodo);

    }

    function clearAll(){
          setTodo([])
    }

    function deleteTodo(indexToDelete){
            
        let newTodos = [...todos];

        delete newTodos[indexToDelete];

        let cleanedNewTodos = newTodos.filter((item) => item);
        
        console.log(cleanedNewTodos);

        setTodo(cleanedNewTodos);
    }
      
    return(
        <div>
            <form onSubmit={add}>
            <h2>Enter Activity Todo{" "}:{" "}<input type="text" name="name" /><br/><br/>
            Select Status{" "}:{" "}
            <select name="status" id="status">
                <option value="">Select Option</option>
                <option value="complete">Complete</option>
                <option value="pending">Pending</option>
            </select></h2>
            <button>Add</button>{" "}
            <button onClick={clearAll}>Clear All</button>
            </form> 
            <ul>
                {
                    todos.map((val, index)=>{
                        return (
                        <li><h3>{val.name}<br/>
                                   {val.status} </h3>
                                   <button type="button" onClick={ () => deleteTodo(index)}>Delete</button>
                                   </li>);
                    })
                }
            </ul>
        </div>
    )
}

export default NewTodod;