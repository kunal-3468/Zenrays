import {useState} from "react";

function Ecommerce(){

    const[product,addProduct] = useState([]);

    function add(event){
        event.preventDefault();
        
        let details ={
            name: event.target.name.value,
            price: event.target.price.value,
            status: event.target.status.value
        }

        console.log(details);

        let newproduct = [...product,details] 

        addProduct(newproduct);

        alert("Pruduct Added");

        event.target.name.value="";
        event.target.price.value="";
        event.target.status.value="";
    }

    // function showAll(){

    //     let htmltoadd="<tr><th>Name</th><th>Price</th><th>Status</th><th>Delete</th><tr>";

    //     console.log(product);

    //     product.map((val,index)=>{
             
    //         htmltoadd = htmltoadd + `<tr>
    //                                  <td>${val.name}</td>
    //                                  <td>${val.price}</td>
    //                                  <td>${val.status}</td>
    //                                  <td><button type="button" onclick="deletePro(${index})">Delete</button></td>
    //                                  </tr>
    //                                  `;
    //     })
        
    //     document.getElementById("tab").innerHTML = htmltoadd ;
    // }

    function clearAll(){
      
         addProduct([]);
    }

    function deletePro(index){
         let newproduct=[...product];

         delete newproduct[index];

         let changedProduct = newproduct.filter((item)=>item);

         addProduct(changedProduct);
    }

     
    return(
        <div>
            <form onSubmit={add}>
            <h2>Enter Name{" "}:{" "}<input type="text" name="name" /><br/>
            Enter Price{" "}:{" "}<input type="text" name="price" /><br/>
            Select Status{" "}:{" "}
            <select name="status" id="status">
                <option value="">Select Option</option>
                <option value="Available">Availabe</option>
                <option value="Not Available">Not Available</option>
            </select></h2>
            <button>Add</button>{" "}
            <button type="button" onClick={clearAll}>Clear All</button>
            </form> 
            <hr/><br/>
            <table border="2">
            <tr><th>Name</th><th>Price</th><th>Status</th><th>Delete</th></tr>
                {product.map((val,index)=>{
                    return(
                        <tr>
                            <td>{val.name}</td>
                            <td>{val.price}</td>
                            <td>{val.status}</td>
                            <td><button type="button" onClick={()=>deletePro(index)}>Delete</button></td>
                        </tr>
                    )
                })}
            </table>
        </div>
    )
}

export default Ecommerce;