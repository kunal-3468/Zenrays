import { Component } from "react";

class TodoForm extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <form onSubmit={this.props.addTodo}>
                <h2>
                    Enter Activity Todo : <input type="text" name="todo" />{" "}
                    <button>Add</button>
                </h2>
            </form>
        )
    }
}

export default TodoForm;