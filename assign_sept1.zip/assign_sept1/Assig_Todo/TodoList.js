import { Component } from "react";
import TodoSingle from "./TodoSingle";

class TodoList extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <ul><h3>Activities Todo : </h3>
                {this.props.todos.map((val, index) => {
                    return (
                        <TodoSingle val={val} index={index} deleteTodo = {this.props.deleteTodo} />
                    )
                })}
            </ul>
        )
    }
}

export default TodoList;