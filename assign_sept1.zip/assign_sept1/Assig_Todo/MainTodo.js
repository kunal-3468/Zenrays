import { Component } from "react";
import TodoList from "./TodoList";
import TodoForm from "./TodoForm";

class MainTodo extends Component {
    constructor() {
        super();

        this.state = {
            todos: [],
        };
    }

    addTodo = (event) => {

        event.preventDefault();

        let newTodos = [...this.state.todos, event.target.todo.value];

        this.setState({ todos: newTodos });

        event.target.todo.value = "";
    };
    deleteTodo = (indexToDelete) => {

        let newTodos = this.state.todos.filter((val, index) => {
            if (index == indexToDelete) return false;
            return true;
        })

        this.setState({ todos: newTodos });
    };
    resetTodo = () => {
        this.setState({ todos: [] });
    };

    render() {
        return (
            <div>
                <button onClick={this.resetTodo}>Clear All</button>
                <TodoForm addTodo={this.addTodo} />
                <br/><hr/>
                <TodoList todos={this.state.todos} deleteTodo={this.deleteTodo} />
            </div>
        )
    }
}

export default MainTodo;