import { Component } from "react";

class TodoSingle extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <li>
                {this.props.val} {" "} <button onClick={() => { this.props.deleteTodo(this.props.index) }} >Delete</button>
            </li>
        )
    }
}

export default TodoSingle;