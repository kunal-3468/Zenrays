import { Component } from "react";

class ClassBasedHobbies extends Component {

    constructor() {
        super();

        this.state = {
            hobby: ["Cycling"],
        }
    }

    AddHobby = (event) => {

        event.preventDefault();

        let newHobby = [...this.state.hobby, event.target.hobby.value]

        this.setState({ hobby: newHobby });

        event.target.hobby.value="";
    }
    ClearAll = () => {
        this.setState({ hobby: [] });
    }

    render() {
        return (
            <div>
                <button onClick={this.ClearAll}>Clear All</button>
                <form onSubmit={this.AddHobby}>
                    <h2>Enter Hobby : {" "} <input type="text" name="hobby" />{" "}
                        <button>Add Hobby</button>
                    </h2>
                </form>
                <br /><hr />
                <ul><h3>Hobbies : <br/><br/>
                    {this.state.hobby.map((val) => {
                        return (
                            <li>{val}</li>
                        )
                    })}
                </h3>
                </ul>
            </div>
        )
    }

}

export default ClassBasedHobbies;