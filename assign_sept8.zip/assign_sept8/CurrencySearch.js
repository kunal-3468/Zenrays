import { useState } from "react";
import axios from "axios";

function CurrencySearch() {

    const [output, setOutput] = useState({});

    function search(event) {

        event.preventDefault();

        let name = event.target.name.value;

        axios.get("https://api.coinbase.com/v2/currencies").then((res) => {

            let data = res.data;
            
            data.data.forEach((val)=>{
                  
                if(name == val.name){
                      
                    setOutput(val);
                }
            })

        })

    }

    return (
        <div>
            <form onSubmit={search}>
                <h2>Enter Currency Name : <input type="text" name="name" /></h2>
                <button>Search</button>
            </form>
            <br/><hr/>
            <h2>
             Name : {output.name}<br/>   
             Id : {output.id}<br/>
             Min. Size : {output.min_size}
            </h2>
        </div>
    )
}

export default CurrencySearch;