import { useState, useEffect } from "react";
import axios from "axios";

function BitcoinCost() {

    const [output,setOutput] = useState();

    useEffect(() => {

        axios.get("https://api.coindesk.com/v1/bpi/currentprice.json").then((res) => {

            let data = res.data;

            console.log(data.bpi.EUR);

            setOutput(`Cost of Bitcoin in EURO is ${data.bpi.EUR.rate}`)
        })
    })

    return (
        <div>
           <h2>{output}</h2>
        </div>
    )
}

export default BitcoinCost;