import { useState } from "react";
import axios from "axios";

function ShowAge(){
    
    const [age,setAge] = useState();
    const [loading,setLoading] = useState(false)

    function show(event){

        event.preventDefault();

        let name = event.target.name.value;

        console.log(name);

        setLoading(true);

         axios.get("https://api.agify.io?name="+name).then((res)=>{
            console.log(res.data);
            
            let details = res.data;

            setAge(`Age Of ${name} is ${details.age}`);
      })
      .finally(()=>{
          setLoading(false);
      })
    }

    return(
        <div>
             <form onSubmit={show}>
             <h2>Enter Name : <input type="text" name="name" /></h2>
             <button>Show Age</button>
             </form>
             <br/><hr/>
             {loading ? <img src="Spinning_arrows.gif" /> : ""} 
             <h2>{age}</h2>
        </div>
    )
}

export default ShowAge;