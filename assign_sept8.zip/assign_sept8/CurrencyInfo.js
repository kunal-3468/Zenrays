import { useEffect , useState } from "react";
import axios from "axios";

function CurrencyInfo(){

    const [output,setOutput] = useState();

    useEffect(()=>{
          
        axios.get("https://api.coinbase.com/v2/currencies").then((res)=>{
             
            let data = res.data;

            console.log(data);

            setOutput(data.data);
             
        })
    },[])

     return(
         <div>
             <table border="2">
                 <tr><th>Id</th><th>Name</th><th>Min. Size</th></tr>
                     {
                         output.map((val)=>{
                             return(
                                 <tr>
                                 <td>{val.id}</td>
                                 <td>{val.name}</td>
                                 <td>{val.min_size}</td>
                                 </tr>
                             )
                         })
                     }
             </table>
         </div>
     )
}

export default CurrencyInfo;