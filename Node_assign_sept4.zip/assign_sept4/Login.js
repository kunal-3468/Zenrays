var http = require("http");

console.log("Server Started");

http.createServer(function(request,response){

	console.log("Running...");

	response.end(`
		    <html>
            <head>
            </head>
            <body>
		    <form>
		    <h2>
		    Enter Email : &nbsp <input type="email" name="email" /><br>
		    Enter Password : &nbsp <input type="password" name="pass" /><br>
		    </h2><br>
		    <button>Submit</button><br>
		    <a href="">Forgot Password</a>
		    </form>
		    </body>
		    </html>
		`)
})
.listen(5000)