const { response } = require("express");
var express = require("express");

var app = express();

app.get("/", function (request, response) {

    response.send(
        `<html>
         <head>
         <style>
         .d1{
             border: 5px solid black;
             padding: 20px;
             margin: 50px;
         }
         .d1 a{
             padding: 11%;
         }
         </style>
         </head>
         <body>
         <div class="d1">
            <a href="/">Home</a>
            <a href="/employee">Employees Information</a>
            <a href="/contact">Contact Us</a>
         </div>
         <br>
         <div>
         <h1>About Company : </h1>
         </div>
         </body>
        </html>`
    )
})

console.log("App is running");

app.get("/employee", function (request, response) {

    response.send(`
        <h1>Employee Information : </h1>
        <br><br>
        <table border="2">
            <tr>
            <th>Name</th>
            <th>Location</th>
            <th>Email Id</th>
            <th>Contact Number</th>
            </tr>
            <tr>
            <td>Abc</td>
            <td>Pujab</td>
            <td>abc@gmail.com</td>
            <td>9875600000</td>
            </tr>
            <tr>
            <td>Kunal Goyal</td>
            <td>Pujab</td>
            <td>goylk0002@gmail.com</td>
            <td>7589062400</td>
            </tr>
            <tr>
            <td>Kunal Goyal</td>
            <td>Pujab</td>
            <td>goylk0002@gmail.com</td>
            <td>7589062400</td>
            </tr>
        </table>
    `)
})

app.get("/contact", function (request, response) {

    response.send(`
        <h1>Contact Us : </h1>
        <form action="/submit">
        <h2>
        Enter Name : &nbsp <input type="text" name="name" /><br>
        Enter Email : &nbsp <input type="email" name="email" /><br><br>
        Description : &nbsp <textarea rows="5" cols="30" name="desc"></textarea><br>
        </h2>
        <button>Submit</button>
        </form>
    `)
});

app.get("/submit", function (request, response) {

    let details = request.query;

    response.send(`
        <h2>
        Name : ${details.name}<br>
        Email : ${details.email}<br>
        Description: ${details.desc}
        </h2>
    `)
})

app.listen(4000);