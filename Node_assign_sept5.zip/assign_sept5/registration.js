var express = require("express");

var app = express();

var bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use(
       bodyParser.urlencoded({
              extended:true,
       })
)

let users = [];

app.get("/register", function(request,response){
       
    response.send(`
        <div>
            <h1>Registration Form : </h1>
            <form method="post" action="/add">
                <h2>
                    Enter Name : &nbsp <input type="text" name="name" /><br/>
                    Enter Email : &nbsp <input type="email" name="email" /><br/>
                    Enter Password : &nbsp <input type="password" name="pass" /><br/>
                    Select Gender : &nbsp 
                    <input type="radio" name="gender" value="Male" /> Male
                    <input type="radio" name="gender" value="Female" />Female <br/>
                    Select City : &nbsp
                    <select name="city">
                        <option>Select City</option> 
                        <option value="Banglore">Banglore</option>
                        <option value="Chennai">Chennai</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Mumbai">Mumbai</option>
                    </select><br/>
                </h2>
                <button>Submit</button>
            </form>
        </div>`
    )
});

app.post("/add", function(request,response){
       
    let {name,email,password,gender,city} = request.body;

    let userOb= {
        name,
        email,
        password,
        gender,
        city
    }

    users.push(userOb);

    console.log(users);
    response.send("User Registered");

})

app.get("/showusers", function(request,response){
       
     let htmltoadd = `<table border="2">
                       <tr>
                           <th>Name</th>
                           <th>Email</th>
                           <th>Password</th>
                           <th>Grnder</th>
                           <th>City</th>`;

     users.forEach((val)=>{
         htmltoadd = htmltoadd + `<tr>
                                  <td>${val.name}</td>
                                  <td>${val.email}</td>
                                  <td>${val.password}</td>
                                  <td>${val.gender}</td>
                                  <td>${val.city}</td>
                                  </tr>`
     })

     htmltoadd = htmltoadd + `</table>`

     response.send(htmltoadd);
})

app.get("/registeredusers", function(request,response){
      
    response.json(users);
})

app.listen(4000)