import {useEffect} from "react";
import axios from "axios";

function DisplayData2(){

    useEffect(function(){
          
        axios.get("data2.json").then(function (res) {
              
          console.log(res.data);

          let details = res.data;

          let htmltoadd =`<tr>
                          <th>Name</th>
                          <th>Mobile</th>
                          <th>Boolean</th>
                          <th>Pets</th>
                          <th>Address</th>
                          </tr>
                          <tr>
                          <td>${details.Name}</td>
                          <td>${details.Mobile}</td>
                          <td>${details.Boolean}</td>
                          <td>${details.Pets}</td>
                          <td>Permanent Address : ${details.Address.Permanentaddress}<br>
                              Current Address : ${details.Address.currentAddress}
                          </td>
                          </tr>
                          `;

          document.getElementById("tab").innerHTML = htmltoadd;

        })

    },[])

    return(
        <div>
            <h1>Display Data : </h1>
            <table border="2" id="tab"></table>
        </div>
    )
}

export default DisplayData2;