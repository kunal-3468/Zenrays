import {useEffect} from "react";
import axios from "axios";

function DisplayData(){

    useEffect(function(){
          
        axios.get("data.json").then(function (res) {
              
          console.log(res.data);

          let details = res.data;

          let htmltoadd ="<tr><th>Firstname</th><th>Lastname</th><th>Gender</th><th>Age</th><th>Adress</th><th>Phone Numbers</th></tr>"
                
            htmltoadd = htmltoadd + `<tr>
                                     <td>${details.firstName}</td>
                                     <td>${details.lastName}</td>
                                     <td>${details.gender}</td>
                                     <td>${details.age}</td>
                                     <td>Street Address : ${details.address.streetAddress}<br>
                                         City : ${details.address.city}<br>
                                         State : ${details.address.state}<br>
                                         Postal Code : ${details.address.postalCode}
                                     </td>
                                     <td> Type : ${details.phoneNumbers[0].type}<br>
                                          Number : ${details.phoneNumbers[0].number}
                                     </td>         
                                     </tr>`

          document.getElementById("tab").innerHTML = htmltoadd;

        })

    })

    return(
        <div>
            <h1>Display Data : </h1>
            <table border="2" id="tab"></table>
        </div>
    )
}

export default DisplayData;