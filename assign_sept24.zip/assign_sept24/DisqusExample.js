import { DiscussionEmbed } from 'disqus-react';
import { CommentCount } from 'disqus-react';
import { Recommendations } from 'disqus-react';
import { CommentEmbed } from 'disqus-react';
import "../App.css"


function DisqusExample() {

    return (
        <div>
            <h1>Disqus Example : </h1>
            <DiscussionEmbed
                className="disquseg"
                shortname='ReactExample'
                config={
                    {
                        url: "http://localhost:3000/",
                        identifier: 1,
                        title: "Hello Welcome All",
                        language: 'en-US' 	
                    }
                }
            />
        </div>
    )

}

export default DisqusExample;