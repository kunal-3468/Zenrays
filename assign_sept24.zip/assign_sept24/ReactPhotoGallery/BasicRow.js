import Gallery from "react-photo-gallery";
import {photos} from "./photos"

function BasicRow(){

    return(
        <div>
            <Gallery photos={photos} />
        </div>
    )
}

export default BasicRow;