import { Component } from "react";
import { IconButton, Tooltip } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete'
import { IsEmpty, Map } from "react-lodash"

class LodashTodolist extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <IsEmpty
                value={this.props.todos}
                yes="Empty list"
                no={() => (
                    <ul>
                        <Map collection={this.props.todos} iteratee={(val, index) => <div>
                            <li key={val}> {val}
                            <Tooltip title="Delete">
                                <IconButton>
                                    <DeleteIcon type="button" onClick={() => { this.props.deleteTodo(index) }} />
                                </IconButton>
                            </Tooltip>
                            </li> </div>} />
                    </ul>
                )}
            />
        )
    }

}

export default LodashTodolist;