import {Component} from "react";
import LodashTodoform from "./LodashTodoForm";
import LodashTodolist from "./LodashTodoList";

var _ = require("lodash");

class LodashTodo extends Component{
      
    constructor(){
        super();

        this.state = {
            todos: ["Workout", "Homework"],
        }
    }

    addTodo = (event) => {
          
        event.preventDefault();

        console.log(event.target.todo.value);

        let newTodo = _.concat(this.state.todos,event.target.todo.value);

        this.setState({todos : newTodo});

        event.target.todo.value="";
    }

    deleteTodo= (index) => {

        let newTodos = _.remove(this.state.todos, function(val,ind){
              
            if(ind == index) return false;
            return true;
        })

        this.setState({todos : newTodos});
    }

    render(){
        return(
            <div>
                <LodashTodoform addTodo={this.addTodo} />
                <br/><hr/>
                <h2>Todo List :-</h2>
                <LodashTodolist todos={this.state.todos} deleteTodo= {this.deleteTodo} />
            </div>
        )
    }
}

export default LodashTodo;