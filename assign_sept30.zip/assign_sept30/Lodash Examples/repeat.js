const _ = require("lodash");

_.times(4, () => {

    console.log("Hey Kunal here");
})