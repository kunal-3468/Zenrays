const _ = require("lodash");

let Ob = { name: 'John', age: 25 };

console.log(_.pick(Ob, 'name'));
console.log(_.pick(Ob, 'age'));