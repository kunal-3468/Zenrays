const _ = require("lodash")

function message()
{
    console.log("Delayed Message");
}

_.delay(message, 3000);
console.log("Normal Message");