const _ = require("lodash");

let val1 = _.range(10);
console.log(val1);

let val2 = _.range(0, 15);
console.log(val2);

let val3 = _.range(0, 15, 5);
console.log(val3);