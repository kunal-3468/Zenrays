const _ = require("lodash");

let words = ["tank", "boy", "tourist", "ten",
        "pen", "car", "marble", "sonnet", "pleasant",
        "ink", "atom"]

console.log("Starting with 't'");
words.forEach( val => {

    if (_.startsWith(val, 't')) {

        console.log(val);
    }
});

console.log("Ending with 'k'");
words.forEach( val => {

    if (_.endsWith(val, 'k')) {

        console.log(val);
    }
});