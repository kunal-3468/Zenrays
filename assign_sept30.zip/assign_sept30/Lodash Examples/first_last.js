const _ = require("lodash")

let words = ['sky', 'wood', 'forest', 'falcon', 
    'pear', 'ocean', 'universe'];

let fn = _.first(words);
let ln = _.last(words);

console.log(`First element: ${fn}`);
console.log(`Last element: ${ln}`);