const _ = require("lodash");

let vals = [-2, 0, 3, 7, -5, 1, 2];

let sum = _.sum(vals);
console.log(sum);