const _ = require("lodash");


let words = ['sky', 'forest', 'wood', 'sky', 'rock', 'cloud', 
    'sky', 'forest', 'rock', 'sky'];

let tally = _.reduce(words, (total, next) => {

  console.log(total);
  console.log(next);
  console.log(total[next]);

  total[next] = (total[next] || 0) + 1 ;

  return total;
}, {sky: 2});


console.log(tally);