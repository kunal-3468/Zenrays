const _ = require("lodash")

let a = _.random(10);
console.log(a);

b = _.random(5, 10);
console.log(b);